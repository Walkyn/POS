@extends('layouts.app')
@section('title', 'Cierre de Turno')

@section('content')
    <main x-data="{ showHistorial: false }">
        <div class="mx-auto max-w-screen-2xl p-4 md:p-6 2xl:p-10">
            <!-- Breadcrumb Start -->
            <div class="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <h2 class="text-title-md2 font-bold text-black dark:text-white">
                    Cierre de Turno
                </h2>

                <nav>
                    <ol class="flex items-center gap-2">
                        <li>
                            <a class="font-medium" href="{{ route('home') }}">Inicio /</a>
                        </li>
                        <li>
                            <a class="font-medium" href="{{ route('sales') }}">Ventas /</a>
                        </li>
                        <li class="font-medium text-primary">Cierre de Turno</li>
                    </ol>
                </nav>
            </div>
            <!-- Breadcrumb End -->

            <!-- ====== Alerts Start ====== -->
            @include('partials.alerts')
            <!-- ====== Alerts End ====== -->

            <!-- ====== Historial de Cierres Section Start ====== -->
            <div x-show="showHistorial" 
                 x-cloak
                 x-transition:enter="transition ease-out duration-300"
                 x-transition:enter-start="opacity-0 -translate-y-4"
                 x-transition:enter-end="opacity-100 translate-y-0"
                 x-transition:leave="transition ease-in duration-200"
                 x-transition:leave-start="opacity-100 translate-y-0"
                 x-transition:leave-end="opacity-0 -translate-y-4"
                 class="mb-6 rounded-sm border border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark">
                <div class="border-b border-stroke px-4 py-3 dark:border-strokedark">
                    <h3 class="text-base md:text-lg font-semibold text-black dark:text-white">
                        Historial de Cierres de Turno
                    </h3>
                </div>
                <div class="p-4">
                    <!-- Tabla Desktop -->
                    <div class="hidden md:block overflow-x-auto">
                        <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                <tr>
                                    <th scope="col" class="px-4 py-3">Fecha</th>
                                    <th scope="col" class="px-4 py-3">Vendedor</th>
                                    <th scope="col" class="px-4 py-3">Total Ventas</th>
                                    <th scope="col" class="px-4 py-3">Tickets</th>
                                    <th scope="col" class="px-4 py-3">Efectivo Inicial</th>
                                    <th scope="col" class="px-4 py-3">Efectivo Final</th>
                                    <th scope="col" class="px-4 py-3">Diferencia</th>
                                    <th scope="col" class="px-4 py-3">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="border-b dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700">
                                    <td class="px-4 py-3">
                                        <span class="text-sm text-gray-600 dark:text-gray-400">15/01/2025 18:30</span>
                                    </td>
                                    <td class="px-4 py-3">
                                        <span class="text-sm font-medium text-gray-900 dark:text-white">Carlos Pérez</span>
                                    </td>
                                    <td class="px-4 py-3">
                                        <span class="text-sm font-semibold text-gray-900 dark:text-white">S/ 1,245.00</span>
                                    </td>
                                    <td class="px-4 py-3">
                                        <span class="text-sm text-gray-600 dark:text-gray-400">12</span>
                                    </td>
                                    <td class="px-4 py-3">
                                        <span class="text-sm text-gray-600 dark:text-gray-400">S/ 500.00</span>
                                    </td>
                                    <td class="px-4 py-3">
                                        <span class="text-sm text-gray-600 dark:text-gray-400">S/ 1,745.00</span>
                                    </td>
                                    <td class="px-4 py-3">
                                        <span class="text-sm font-semibold text-green-600 dark:text-green-400">S/ 1,245.00</span>
                                    </td>
                                    <td class="px-4 py-3">
                                        <button type="button"
                                                class="flex items-center justify-center text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded text-sm p-2 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-900">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <!-- Cards Móvil -->
                    <div class="md:hidden space-y-3">
                        <div class="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-4">
                            <div class="flex items-center justify-between mb-3">
                                <div>
                                    <p class="text-xs text-gray-500 dark:text-gray-400">Fecha</p>
                                    <p class="text-sm font-semibold text-gray-900 dark:text-white">15/01/2025 18:30</p>
                                </div>
                                <div>
                                    <p class="text-xs text-gray-500 dark:text-gray-400">Vendedor</p>
                                    <p class="text-sm font-semibold text-gray-900 dark:text-white">Carlos Pérez</p>
                                </div>
                            </div>
                            <div class="grid grid-cols-2 gap-3 mb-3">
                                <div>
                                    <p class="text-xs text-gray-500 dark:text-gray-400 mb-1">Total Ventas</p>
                                    <p class="text-sm font-semibold text-gray-900 dark:text-white">S/ 1,245.00</p>
                                </div>
                                <div>
                                    <p class="text-xs text-gray-500 dark:text-gray-400 mb-1">Tickets</p>
                                    <p class="text-sm font-semibold text-gray-900 dark:text-white">12</p>
                                </div>
                                <div>
                                    <p class="text-xs text-gray-500 dark:text-gray-400 mb-1">Efectivo Inicial</p>
                                    <p class="text-sm text-gray-600 dark:text-gray-400">S/ 500.00</p>
                                </div>
                                <div>
                                    <p class="text-xs text-gray-500 dark:text-gray-400 mb-1">Efectivo Final</p>
                                    <p class="text-sm text-gray-600 dark:text-gray-400">S/ 1,745.00</p>
                                </div>
                            </div>
                            <div class="flex items-center justify-between pt-3 border-t border-gray-200 dark:border-gray-700">
                                <div>
                                    <p class="text-xs text-gray-500 dark:text-gray-400 mb-1">Diferencia</p>
                                    <p class="text-sm font-semibold text-green-600 dark:text-green-400">S/ 1,245.00</p>
                                </div>
                                <button type="button"
                                        class="flex items-center justify-center text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded text-sm p-2 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-900">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Mensaje cuando no hay datos -->
                    <div class="text-center py-8 text-gray-500 dark:text-gray-400">
                        <i class="fas fa-history text-3xl mb-2 opacity-50"></i>
                        <p class="text-sm">No hay cierres de turno registrados</p>
                    </div>
                </div>
            </div>
            <!-- ====== Historial de Cierres Section End ====== -->

            <!-- ====== Cierre de Turno Section Start ====== -->
            <div class="flex flex-col gap-6">
                <!-- Panel de Información -->
                <div class="rounded-lg md:rounded-sm border border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark">
                    <div class="border-b border-stroke px-4 py-3 dark:border-strokedark flex items-center justify-between">
                        <div class="flex items-center gap-2">
                            <i class="fas fa-shopping-cart text-primary dark:text-white"></i>
                            <h3 class="text-base md:text-lg font-semibold text-black dark:text-white">
                                Panel de Información
                            </h3>
                        </div>
                        <button @click="showHistorial = !showHistorial"
                                class="flex items-center justify-center gap-2 text-gray-700 hover:text-white border border-gray-700 hover:bg-gray-800 focus:ring-4 focus:outline-none focus:ring-gray-300 font-medium rounded-lg text-sm py-2 px-4 text-center dark:border-gray-500 dark:text-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-900">
                            <i class="fas fa-history"></i>
                            <span class="hidden sm:inline">Historial</span>
                        </button>
                    </div>
                    <div class="p-4 md:p-6">
                        <!-- Total de Venta -->
                        <div class="mb-4 p-4 rounded-lg border-2 border-primary dark:border-primary bg-primary/5 dark:bg-primary/10">
                            <div class="flex items-center justify-between">
                                <div class="flex items-center gap-3">
                                    <div class="flex h-10 w-10 items-center justify-center rounded-full bg-primary/20 dark:bg-primary/30">
                                        <i class="fas fa-shopping-cart text-primary dark:text-primary text-lg"></i>
                                    </div>
                                    <div>
                                        <p class="text-xs font-medium text-gray-600 dark:text-gray-400">Total de venta</p>
                                        <p class="text-xl font-bold text-gray-900 dark:text-white font-numbers">S/ 0.00</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Tarjetas de Información -->
                        <div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
                            <!-- Fondo Caja -->
                            <div class="flex items-center gap-3 p-3 rounded-lg border border-stroke dark:border-strokedark bg-gray-50 dark:bg-gray-800/50">
                                <div class="flex h-8 w-8 items-center justify-center rounded-full bg-meta-2 dark:bg-meta-4 flex-shrink-0">
                                    <i class="fas fa-wallet text-primary dark:text-white text-sm"></i>
                                </div>
                                <div class="min-w-0 flex-1">
                                    <p class="text-xs text-gray-500 dark:text-gray-400">Fondo caja</p>
                                    <p class="text-sm font-bold text-black dark:text-white font-numbers">S/ 0.00</p>
                                </div>
                            </div>

                            <!-- Entradas -->
                            <div class="flex items-center gap-3 p-3 rounded-lg border border-stroke dark:border-strokedark bg-gray-50 dark:bg-gray-800/50">
                                <div class="flex h-8 w-8 items-center justify-center rounded-full bg-meta-2 dark:bg-meta-4 flex-shrink-0">
                                    <i class="fas fa-arrow-down text-primary dark:text-white text-sm"></i>
                                </div>
                                <div class="min-w-0 flex-1">
                                    <p class="text-xs text-gray-500 dark:text-gray-400">Entradas</p>
                                    <p class="text-sm font-bold text-green-600 dark:text-green-400 font-numbers">S/ 0.00</p>
                                </div>
                            </div>

                            <!-- Salidas -->
                            <div class="flex items-center gap-3 p-3 rounded-lg border border-stroke dark:border-strokedark bg-gray-50 dark:bg-gray-800/50">
                                <div class="flex h-8 w-8 items-center justify-center rounded-full bg-meta-2 dark:bg-meta-4 flex-shrink-0">
                                    <i class="fas fa-arrow-up text-primary dark:text-white text-sm"></i>
                                </div>
                                <div class="min-w-0 flex-1">
                                    <p class="text-xs text-gray-500 dark:text-gray-400">Salidas</p>
                                    <p class="text-sm font-bold text-red-600 dark:text-red-400 font-numbers">S/ 0.00</p>
                                </div>
                            </div>

                            <!-- Dinero en Caja -->
                            <div class="flex items-center gap-3 p-3 rounded-lg border border-stroke dark:border-strokedark bg-gray-50 dark:bg-gray-800/50">
                                <div class="flex h-8 w-8 items-center justify-center rounded-full bg-meta-2 dark:bg-meta-4 flex-shrink-0">
                                    <i class="fas fa-cash-register text-primary dark:text-white text-sm"></i>
                                </div>
                                <div class="min-w-0 flex-1">
                                    <p class="text-xs text-gray-500 dark:text-gray-400">Dinero en caja</p>
                                    <p class="text-sm font-bold text-black dark:text-white font-numbers">S/ 0.00</p>
                                </div>
                            </div>
                        </div>

                        <!-- Formulario de Registro -->
                        <form class="space-y-4 border-t border-gray-200 dark:border-gray-700 pt-6">
                            <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                                <!-- Efectivo Inicial -->
                                <div>
                                    <label class="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">
                                        Efectivo Inicial
                                    </label>
                                    <input type="number" 
                                           step="0.01" 
                                           placeholder="0.00"
                                           style="appearance: none; -webkit-appearance: none; -moz-appearance: textfield;"
                                           class="w-full text-sm text-gray-900 dark:text-white bg-white dark:bg-gray-800 md:bg-transparent border-[0.5px] border-gray-300 dark:border-gray-600 rounded-lg md:rounded px-3 md:px-2 py-2 md:py-2.5 focus:outline-none focus:ring-2 md:focus:ring-1 focus:ring-blue-500 dark:focus:ring-blue-400 placeholder:text-gray-400 placeholder:opacity-60 dark:placeholder:text-gray-500 dark:placeholder:opacity-60">
                                </div>

                                <!-- Efectivo Final -->
                                <div>
                                    <label class="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">
                                        Efectivo Final
                                    </label>
                                    <input type="number" 
                                           step="0.01" 
                                           placeholder="0.00"
                                           style="appearance: none; -webkit-appearance: none; -moz-appearance: textfield;"
                                           class="w-full text-sm text-gray-900 dark:text-white bg-white dark:bg-gray-800 md:bg-transparent border-[0.5px] border-gray-300 dark:border-gray-600 rounded-lg md:rounded px-3 md:px-2 py-2 md:py-2.5 focus:outline-none focus:ring-2 md:focus:ring-1 focus:ring-blue-500 dark:focus:ring-blue-400 placeholder:text-gray-400 placeholder:opacity-60 dark:placeholder:text-gray-500 dark:placeholder:opacity-60">
                                </div>
                            </div>

                            <!-- Observaciones -->
                            <div>
                                <label class="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">
                                    Observaciones
                                </label>
                                <textarea rows="3" 
                                          placeholder="Ingrese observaciones del turno..."
                                          style="appearance: none; -webkit-appearance: none; -moz-appearance: textfield;"
                                          class="w-full text-sm text-gray-600 dark:text-gray-400 bg-white dark:bg-gray-800 md:bg-transparent border-[0.5px] border-gray-300 dark:border-gray-600 rounded-lg md:rounded px-3 md:px-2 py-2 md:py-2 focus:outline-none focus:ring-2 md:focus:ring-1 focus:ring-blue-500 dark:focus:ring-blue-400 resize-none break-words block placeholder:text-gray-400 placeholder:opacity-60 dark:placeholder:text-gray-500 dark:placeholder:opacity-60"></textarea>
                            </div>

                            <!-- Botones -->
                            <div class="flex flex-col gap-3 sm:flex-row sm:justify-end pt-2">
                                <a href="{{ route('sales') }}" 
                                   class="flex w-full sm:w-auto items-center justify-center text-gray-700 hover:text-white border border-gray-700 hover:bg-gray-800 focus:ring-4 focus:outline-none focus:ring-gray-300 font-medium rounded-lg text-sm py-2.5 px-6 text-center dark:border-gray-500 dark:text-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-900">
                                    <span>Cancelar</span>
                                </a>
                                <button type="submit"
                                        class="flex w-full sm:w-auto items-center justify-center gap-2 text-white bg-blue-700 hover:bg-blue-800 border border-blue-700 hover:border-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm py-2.5 px-6 text-center dark:bg-blue-600 dark:border-blue-600 dark:hover:bg-blue-700 dark:hover:border-blue-700 dark:focus:ring-blue-900">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clip-rule="evenodd" />
                                    </svg>
                                    <span>Registrar</span>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Tipos de Pago -->
                <div class="rounded-lg md:rounded-sm border border-stroke bg-white shadow-default dark:border-strokedark dark:bg-boxdark">
                    <div class="border-b border-stroke px-4 py-3 dark:border-strokedark">
                        <h3 class="text-base md:text-lg font-semibold text-black dark:text-white">
                            Total pagos recibidos
                        </h3>
                    </div>
                    <div class="p-4">
                        <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
                            <!-- Efectivo -->
                            <div class="flex items-center gap-3 p-3 rounded-lg border border-stroke dark:border-strokedark bg-gray-50 dark:bg-gray-800/50">
                                <div class="flex h-8 w-8 items-center justify-center rounded-full bg-meta-2 dark:bg-meta-4 flex-shrink-0">
                                    <i class="fas fa-money-bill-wave text-primary dark:text-white text-sm"></i>
                                </div>
                                <div class="min-w-0 flex-1">
                                    <p class="text-xs text-gray-500 dark:text-gray-400">Efectivo</p>
                                    <p class="text-sm font-bold text-black dark:text-white font-numbers">S/ 0.00</p>
                                </div>
                            </div>

                            <!-- Tarjeta -->
                            <div class="flex items-center gap-3 p-3 rounded-lg border border-stroke dark:border-strokedark bg-gray-50 dark:bg-gray-800/50">
                                <div class="flex h-8 w-8 items-center justify-center rounded-full bg-meta-2 dark:bg-meta-4 flex-shrink-0">
                                    <i class="fas fa-credit-card text-primary dark:text-white text-sm"></i>
                                </div>
                                <div class="min-w-0 flex-1">
                                    <p class="text-xs text-gray-500 dark:text-gray-400">Tarjeta</p>
                                    <p class="text-sm font-bold text-black dark:text-white font-numbers">S/ 0.00</p>
                                </div>
                            </div>

                            <!-- Yape -->
                            <div class="flex items-center gap-3 p-3 rounded-lg border border-stroke dark:border-strokedark bg-gray-50 dark:bg-gray-800/50">
                                <div class="flex h-8 w-8 items-center justify-center rounded-full bg-meta-2 dark:bg-meta-4 flex-shrink-0">
                                    <i class="fas fa-mobile-alt text-primary dark:text-white text-sm"></i>
                                </div>
                                <div class="min-w-0 flex-1">
                                    <p class="text-xs text-gray-500 dark:text-gray-400">Yape</p>
                                    <p class="text-sm font-bold text-black dark:text-white font-numbers">S/ 0.00</p>
                                </div>
                            </div>

                            <!-- Plin -->
                            <div class="flex items-center gap-3 p-3 rounded-lg border border-stroke dark:border-strokedark bg-gray-50 dark:bg-gray-800/50">
                                <div class="flex h-8 w-8 items-center justify-center rounded-full bg-meta-2 dark:bg-meta-4 flex-shrink-0">
                                    <i class="fas fa-wallet text-primary dark:text-white text-sm"></i>
                                </div>
                                <div class="min-w-0 flex-1">
                                    <p class="text-xs text-gray-500 dark:text-gray-400">Plin</p>
                                    <p class="text-sm font-bold text-black dark:text-white font-numbers">S/ 0.00</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <!-- ====== Cierre de Turno Section End ====== -->
        </div>
    </main>

@endsection

