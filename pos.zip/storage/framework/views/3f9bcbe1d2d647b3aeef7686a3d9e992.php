<main class="h-full pb-16 overflow-y-auto" x-data="{ 
    searchQuery: '',
    activeTab: 'stock',
    stockMinimo: '',
    stockMaximo: '',
    diferenciaMinima: '',
    diferenciaMaxima: '',
    categoriasSeleccionadas: [],
    filterDropdownOpen: false,
    isUpdateInventoryModal: false,
    isExportingExcel: false,
    exportProgress: 0,
    categorias: [
        { id: 1, nombre: 'Electrónica' },
        { id: 2, nombre: 'Accesorios' },
        { id: 3, nombre: 'Computadoras' },
        { id: 4, nombre: 'Periféricos' }
    ],
    exportarExcel() {
        // Resetear progreso
        this.exportProgress = 0;
        // Mostrar modal de loading
        this.isExportingExcel = true;
        
        // Simular exportación con progreso (aquí iría la llamada real al backend)
        let progress = 0;
        const interval = setInterval(() => {
            progress += 2;
            this.exportProgress = progress;
            if (progress >= 100) {
                clearInterval(interval);
                setTimeout(() => {
                    this.isExportingExcel = false;
                    this.exportProgress = 0;
                    // Aquí se descargaría el archivo Excel
                    console.log('Exportar a Excel');
                }, 300);
            }
        }, 40);
    },
    actualizarInventario() {
        // Abrir modal de confirmación siempre
        console.log('actualizarInventario llamado');
        console.log('isUpdateInventoryModal antes:', this.isUpdateInventoryModal);
        this.isUpdateInventoryModal = true;
        console.log('isUpdateInventoryModal después:', this.isUpdateInventoryModal);
        // Forzar actualización
        this.$nextTick(() => {
            console.log('Después de nextTick:', this.isUpdateInventoryModal);
        });
    },
    confirmarActualizacion() {
        // Filtrar solo los productos con stock físico >= 0 y que tengan cambios
        const cambios = this.inventarioFiltrado.filter(item => 
            item.stock_fisico !== item.stock_actual && item.stock_fisico >= 0
        );
        
        if (cambios.length === 0) {
            this.isUpdateInventoryModal = false;
            return;
        }
        
        // Cerrar modal
        this.isUpdateInventoryModal = false;
        
        // Aquí iría la llamada al backend para actualizar
        console.log('Actualizar inventario:', cambios);
        // TODO: Llamar al endpoint del backend para actualizar el stock
    },
    inventario: [
        {
            id: 1,
            codigo: 'LP001',
            nombre: 'Laptop Dell Inspiron 15',
            categoria: 'Electrónica',
            lote: 'LOTE-001',
            vencimiento: '2025-12-31',
            precio_costo: 800.00,
            stock_actual: 25,
            stock_fisico: 25,
            stock_minimo: 10,
            ubicacion: 'Almacén A',
            ultimo_movimiento: '2025-01-15',
            estado: 'disponible'
        },
        {
            id: 2,
            codigo: 'MS002',
            nombre: 'Mouse Inalámbrico Logitech',
            categoria: 'Accesorios',
            lote: 'LOTE-002',
            vencimiento: '2026-06-30',
            precio_costo: 25.50,
            stock_actual: 50,
            stock_fisico: 50,
            stock_minimo: 20,
            ubicacion: 'Almacén B',
            ultimo_movimiento: '2025-01-14',
            estado: 'disponible'
        }
    ],
    inventarioFiltrado: [],
    init() {
        this.inventarioFiltrado = this.inventario;
    },
    filtrarInventario() {
        const query = this.searchQuery.toLowerCase().trim();
        let filtrados = this.inventario;
        
        // Filtrar por rango de stock
        if (this.stockMinimo && this.stockMinimo !== '') {
            const stockMin = parseInt(this.stockMinimo);
            if (!isNaN(stockMin)) {
                filtrados = filtrados.filter(item => item.stock_actual >= stockMin);
            }
        }
        if (this.stockMaximo && this.stockMaximo !== '') {
            const stockMax = parseInt(this.stockMaximo);
            if (!isNaN(stockMax)) {
                filtrados = filtrados.filter(item => item.stock_actual <= stockMax);
            }
        }
        
        // Filtrar por rango de diferencia
        if (this.diferenciaMinima && this.diferenciaMinima !== '') {
            const diffMin = parseInt(this.diferenciaMinima);
            if (!isNaN(diffMin)) {
                filtrados = filtrados.filter(item => {
                    const diferencia = item.stock_fisico - item.stock_actual;
                    return diferencia >= diffMin;
                });
            }
        }
        if (this.diferenciaMaxima && this.diferenciaMaxima !== '') {
            const diffMax = parseInt(this.diferenciaMaxima);
            if (!isNaN(diffMax)) {
                filtrados = filtrados.filter(item => {
                    const diferencia = item.stock_fisico - item.stock_actual;
                    return diferencia <= diffMax;
                });
            }
        }
        
        // Filtrar por categoría
        if (this.categoriasSeleccionadas.length > 0) {
            const categoriasNombres = this.categorias
                .filter(c => this.categoriasSeleccionadas.includes(c.id))
                .map(c => c.nombre);
            filtrados = filtrados.filter(item => categoriasNombres.includes(item.categoria));
        }
        
        // Filtrar por búsqueda
        if (query) {
            filtrados = filtrados.filter(item => 
                item.nombre.toLowerCase().includes(query) ||
                item.codigo.toLowerCase().includes(query) ||
                (item.lote && item.lote.toLowerCase().includes(query))
            );
        }
        
        this.inventarioFiltrado = filtrados;
    }
}" x-init="filtrarInventario()">
    <div>
        <section class="dark:bg-gray-900 antialiased">
            <div class="max-w-screen-2xl">
                <div class="bg-white dark:bg-gray-800 relative shadow-md sm:rounded-none rounded-lg overflow-hidden">
                    <div
                        class="flex flex-col md:flex-row md:items-center md:justify-between space-y-2 md:space-y-0 md:space-x-4 p-4">
                        
                        <div class="w-full md:w-1/2 lg:w-2/3 order-2 md:order-1 mt-2 md:mt-0">
                            <form class="flex items-center" id="searchForm">
                                <label for="simple-search" class="sr-only">Buscar en inventario</label>
                                <div class="relative w-full group">
                                    <div class="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none transition-colors duration-200">
                                        <svg class="w-5 h-5 text-gray-400 dark:text-gray-500 search-icon group-focus-within:text-primary-600 dark:group-focus-within:text-primary-400 transition-colors duration-200" fill="none"
                                            stroke="currentColor" viewBox="0 0 24 24"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                                        </svg>
                                    </div>
                                    <input type="text" 
                                        x-model="searchQuery"
                                        @input="filtrarInventario()"
                                        class="w-full pl-12 pr-10 text-sm text-gray-900 dark:text-white bg-white dark:bg-gray-800 border-[0.5px] border-gray-300 dark:border-gray-600 rounded-lg px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 placeholder:text-gray-400 placeholder:opacity-60 dark:placeholder:text-gray-500 dark:placeholder:opacity-60"
                                        placeholder="Buscar por nombre, código o lote...">
                                    <button type="button"
                                        x-show="searchQuery"
                                        @click="searchQuery = ''; filtrarInventario();"
                                        class="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300 transition-colors duration-200">
                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M6 18L18 6M6 6l12 12"></path>
                                        </svg>
                                    </button>
                                </div>
                            </form>
                        </div>

                        
                        <div class="w-full md:w-auto order-1 md:order-2 relative" x-data="{ 
                            filterOpen: false,
                            cerrarTodasLasSecciones() {
                                setTimeout(() => {
                                    const accordionButtons = document.querySelectorAll('#filterDropdown [data-accordion-target]');
                                    accordionButtons.forEach(btn => {
                                        const target = btn.getAttribute('data-accordion-target');
                                        const body = document.querySelector(target);
                                        if (body && !body.classList.contains('hidden')) {
                                            body.classList.add('hidden');
                                            btn.setAttribute('aria-expanded', 'false');
                                            const icon = btn.querySelector('[data-accordion-icon]');
                                            if (icon) icon.classList.remove('rotate-180');
                                        }
                                    });
                                }, 50);
                            }
                        }">
                            <button id="filterDropdownButton"
                                @click="filterOpen = !filterOpen; if (filterOpen) cerrarTodasLasSecciones();"
                                type="button"
                                class="w-full md:w-auto flex items-center justify-center py-2.5 px-6 text-sm font-medium focus:outline-none rounded-lg border bg-white text-gray-900 border-gray-200 hover:bg-gray-100 hover:text-primary-700 focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700">
                                <i class="fas fa-filter mr-2"></i>
                                Filtrar
                                <svg class="ml-2 w-4 h-4 text-gray-400 transition-transform duration-200" :class="{ 'rotate-180': filterOpen }" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                                </svg>
                            </button>

                            
                            <div id="filterDropdown"
                                x-show="filterOpen"
                                x-transition:enter="transition ease-out duration-200"
                                x-transition:enter-start="opacity-0 scale-95"
                                x-transition:enter-end="opacity-100 scale-100"
                                x-transition:leave="transition ease-in duration-150"
                                x-transition:leave-start="opacity-100 scale-100"
                                x-transition:leave-end="opacity-0 scale-95"
                                @click.away="filterOpen = false"
                                x-cloak
                                class="absolute z-50 w-full md:w-80 mt-2 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
                                <div class="flex items-center justify-between px-4 py-3 border-b border-gray-200 dark:border-gray-700">
                                    <h6 class="text-sm font-medium text-gray-900 dark:text-white">Filtros</h6>
                                    <button type="button" id="limpiar-filtros"
                                        @click="stockMinimo = ''; stockMaximo = ''; diferenciaMinima = ''; diferenciaMaxima = ''; categoriasSeleccionadas = []; filtrarInventario();"
                                        class="text-sm font-medium text-primary-600 dark:text-primary-500 hover:underline">
                                        Limpiar
                                    </button>
                                </div>

                                <div id="accordion-flush" data-accordion="collapse" data-active-classes="text-black dark:text-white"
                                    data-inactive-classes="text-gray-500 dark:text-gray-400">
                                    
                                    <h2 id="stock-heading">
                                        <button type="button"
                                            class="flex items-center justify-between w-full py-3 px-4 text-sm font-medium text-left text-gray-700 dark:text-gray-300 border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700"
                                            data-accordion-target="#stock-body" aria-expanded="false" aria-controls="stock-body">
                                            <span>Stock</span>
                                            <svg aria-hidden="true" data-accordion-icon="" class="w-5 h-5 shrink-0"
                                                fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" />
                                            </svg>
                                        </button>
                                    </h2>
                                    <div id="stock-body" class="hidden" aria-labelledby="stock-heading" aria-expanded="false">
                                        <div class="py-3 px-4 font-light border-b border-gray-200 dark:border-gray-700">
                                            <div class="space-y-3">
                                                <div>
                                                    <label for="stock_minimo"
                                                        class="block text-sm font-medium text-gray-700 dark:text-gray-300">Stock Mínimo</label>
                                                    <input type="number" id="stock_minimo" name="stock_minimo" x-model="stockMinimo" @input="filtrarInventario()" min="0"
                                                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white py-2.5 px-3"
                                                        placeholder="Ej: 0, 10, 20...">
                                                </div>
                                                <div>
                                                    <label for="stock_maximo"
                                                        class="block text-sm font-medium text-gray-700 dark:text-gray-300">Stock Máximo</label>
                                                    <input type="number" id="stock_maximo" name="stock_maximo" x-model="stockMaximo" @input="filtrarInventario()" min="0"
                                                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white py-2.5 px-3"
                                                        placeholder="Ej: 50, 100, 200...">
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    
                                    <h2 id="diferencia-heading">
                                        <button type="button"
                                            class="flex items-center justify-between w-full py-3 px-4 text-sm font-medium text-left text-gray-700 dark:text-gray-300 border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700"
                                            data-accordion-target="#diferencia-body" aria-expanded="false"
                                            aria-controls="diferencia-body">
                                            <span>Diferencia</span>
                                            <svg aria-hidden="true" data-accordion-icon="" class="w-5 h-5 shrink-0"
                                                fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" />
                                            </svg>
                                        </button>
                                    </h2>
                                    <div id="diferencia-body" class="hidden" aria-labelledby="diferencia-heading" aria-expanded="false">
                                        <div class="py-3 px-4 font-light border-b border-gray-200 dark:border-gray-700">
                                            <div class="space-y-3">
                                                <div>
                                                    <label for="diferencia_minima"
                                                        class="block text-sm font-medium text-gray-700 dark:text-gray-300">Diferencia Mínima</label>
                                                    <input type="number" id="diferencia_minima" name="diferencia_minima" x-model="diferenciaMinima" @input="filtrarInventario()"
                                                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white py-2.5 px-3"
                                                        placeholder="Ej: -10, -5, 0...">
                                                </div>
                                                <div>
                                                    <label for="diferencia_maxima"
                                                        class="block text-sm font-medium text-gray-700 dark:text-gray-300">Diferencia Máxima</label>
                                                    <input type="number" id="diferencia_maxima" name="diferencia_maxima" x-model="diferenciaMaxima" @input="filtrarInventario()"
                                                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white py-2.5 px-3"
                                                        placeholder="Ej: 0, 5, 10...">
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    
                                    <h2 id="categoria-heading">
                                        <button type="button"
                                            class="flex items-center justify-between w-full py-3 px-4 text-sm font-medium text-left text-gray-700 dark:text-gray-300 border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700"
                                            data-accordion-target="#categoria-body" aria-expanded="false"
                                            aria-controls="categoria-body">
                                            <span>Categoría</span>
                                            <svg aria-hidden="true" data-accordion-icon="" class="w-5 h-5 shrink-0"
                                                fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" />
                                            </svg>
                                        </button>
                                    </h2>
                                    <div id="categoria-body" class="hidden" aria-labelledby="categoria-heading" aria-expanded="false">
                                        <div class="py-3 px-4 font-light border-b border-gray-200 dark:border-gray-700">
                                            <ul class="space-y-2">
                                                <template x-for="categoria in categorias" :key="categoria.id">
                                                    <li class="flex items-center">
                                                        <input :id="'categoria-' + categoria.id" type="checkbox" x-model="categoriasSeleccionadas" :value="categoria.id" @change="filtrarInventario()"
                                                            class="w-4 h-4 bg-gray-100 border-gray-300 rounded text-primary-600 focus:ring-primary-500 dark:focus:ring-primary-600 dark:ring-offset-gray-700 focus:ring-2 dark:bg-gray-600 dark:border-gray-500">
                                                        <label :for="'categoria-' + categoria.id"
                                                            class="ml-2 text-sm font-medium text-gray-900 dark:text-gray-100" x-text="categoria.nombre"></label>
                                                    </li>
                                                </template>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        
                        <div class="hidden md:flex md:flex-row gap-3 w-auto order-3">
                            <button @click="activeTab = 'stock'"
                                type="button"
                                :class="activeTab === 'stock' 
                                    ? 'flex-1 flex items-center justify-center py-2.5 px-6 text-sm font-medium focus:outline-none rounded-lg border bg-blue-600 text-white border-blue-600 hover:bg-blue-700 focus:z-10 focus:ring-4 focus:ring-blue-200 dark:focus:ring-blue-700' 
                                    : 'flex-1 flex items-center justify-center py-2.5 px-6 text-sm font-medium focus:outline-none rounded-lg border bg-white text-gray-900 border-gray-200 hover:bg-gray-100 hover:text-primary-700 focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700'">
                                <i class="fas fa-boxes mr-2"></i>
                                Stock
                            </button>

                            <a href="<?php echo e(route('inventory.movements')); ?>"
                                type="button"
                                class="flex-1 flex items-center justify-center py-2.5 px-6 text-sm font-medium focus:outline-none rounded-lg border bg-white text-gray-900 border-gray-200 hover:bg-gray-100 hover:text-primary-700 focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700">
                                <i class="fas fa-exchange-alt mr-2"></i>
                                Movimientos
                            </a>

                            <a href="<?php echo e(route('inventory.expired')); ?>"
                                type="button"
                                class="flex-1 flex items-center justify-center py-2.5 px-6 text-sm font-medium focus:outline-none rounded-lg border bg-white text-gray-900 border-gray-200 hover:bg-gray-100 hover:text-primary-700 focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700">
                                <i class="fas fa-calendar-times mr-2"></i>
                                Vencidos
                            </a>

                            <a href="<?php echo e(route('inventory.out-of-stock')); ?>"
                                type="button"
                                class="flex-1 flex items-center justify-center py-2.5 px-6 text-sm font-medium focus:outline-none rounded-lg border bg-white text-gray-900 border-gray-200 hover:bg-gray-100 hover:text-primary-700 focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700">
                                <i class="fas fa-exclamation-triangle mr-2"></i>
                                Agotados
                            </a>
                        </div>

                        
                        <div class="md:hidden w-full order-1 md:order-2 relative" x-data="{ showDropdown: false }">
                            <button @click="showDropdown = !showDropdown"
                                type="button"
                                class="w-full flex items-center justify-between py-2.5 px-4 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700">
                                <span class="flex items-center">
                                    <i class="fas fa-tasks mr-2 text-gray-400"></i>
                                    <span x-text="activeTab === 'stock' ? 'Stock' : activeTab === 'movimientos' ? 'Movimientos' : 'Agotados'"></span>
                                </span>
                                <svg class="w-4 h-4 text-gray-400 transition-transform duration-200" :class="{ 'rotate-180': showDropdown }" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                                </svg>
                            </button>

                            <div x-show="showDropdown"
                                 x-transition:enter="transition ease-out duration-200"
                                 x-transition:enter-start="opacity-0 scale-95"
                                 x-transition:enter-end="opacity-100 scale-100"
                                 x-transition:leave="transition ease-in duration-150"
                                 x-transition:leave-start="opacity-100 scale-100"
                                 x-transition:leave-end="opacity-0 scale-95"
                                 @click.away="showDropdown = false"
                                 x-cloak
                                 class="absolute z-50 w-full mt-2 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
                                <button @click="activeTab = 'stock'; showDropdown = false"
                                    type="button"
                                    :class="activeTab === 'stock' ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300' : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'"
                                    class="w-full flex items-center px-4 py-3 text-sm">
                                    <i class="fas fa-boxes mr-3"></i>
                                    Stock
                                </button>
                                <a href="<?php echo e(route('inventory.movements')); ?>"
                                    type="button"
                                    class="w-full flex items-center px-4 py-3 text-sm border-t border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700">
                                    <i class="fas fa-exchange-alt mr-3"></i>
                                    Movimientos
                                </a>
                                <a href="<?php echo e(route('inventory.expired')); ?>"
                                    type="button"
                                    class="w-full flex items-center px-4 py-3 text-sm border-t border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700">
                                    <i class="fas fa-calendar-times mr-3"></i>
                                    Vencidos
                                </a>
                                <a href="<?php echo e(route('inventory.out-of-stock')); ?>"
                                    type="button"
                                    class="w-full flex items-center px-4 py-3 text-sm border-t border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700">
                                    <i class="fas fa-exclamation-triangle mr-3"></i>
                                    Agotados
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="overflow-x-auto">
                        
                        <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400 hidden md:table">
                            <thead
                                class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                <tr>
                                    <th scope="col" class="p-4">Producto</th>
                                    <th scope="col" class="p-4">Lote</th>
                                    <th scope="col" class="p-4 whitespace-nowrap">Stock</th>
                                    <th scope="col" class="p-4 whitespace-nowrap">Físico</th>
                                    <th scope="col" class="p-4 whitespace-nowrap">Diferencia</th>
                                    <th scope="col" class="p-4 whitespace-nowrap">P. Costo</th>
                                    <th scope="col" class="p-4 whitespace-nowrap">Valor</th>
                                    <th scope="col" class="p-4">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <template x-for="(item, index) in inventarioFiltrado" :key="item.id">
                                    <tr class="border-b dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700">
                                        <td class="px-4 py-3 font-medium text-gray-900 dark:text-white">
                                            <div class="flex flex-col">
                                                <div class="mb-1">
                                                    <span class="text-base font-semibold text-black dark:text-white block" x-text="item.nombre"></span>
                                                </div>
                                                <div>
                                                    <span class="text-xs text-gray-500 dark:text-gray-400 font-mono block" x-text="item.codigo"></span>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-4 py-3">
                                            <span class="text-sm text-gray-600 dark:text-gray-400" x-text="item.lote || 'N/A'"></span>
                                        </td>
                                        <td class="px-4 py-3">
                                            <span class="font-semibold text-gray-900 dark:text-white" x-text="item.stock_actual"></span>
                                        </td>
                                        <td class="px-4 py-3">
                                            <input type="number" 
                                                x-model="item.stock_fisico"
                                                class="w-20 px-2 py-1.5 text-sm text-gray-900 dark:text-white bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400"
                                                min="0"
                                                step="1">
                                        </td>
                                        <td class="px-4 py-3">
                                            <span :class="(item.stock_fisico - item.stock_actual) > 0 ? 'text-green-600 dark:text-green-400' : (item.stock_fisico - item.stock_actual) < 0 ? 'text-red-600 dark:text-red-400' : 'text-gray-600 dark:text-gray-400'"
                                                class="font-semibold text-sm"
                                                x-text="(item.stock_fisico - item.stock_actual) > 0 ? '+' + (item.stock_fisico - item.stock_actual) : (item.stock_fisico - item.stock_actual)"></span>
                                        </td>
                                        <td class="px-4 py-3">
                                            <span class="font-semibold text-gray-900 dark:text-white" x-text="'S/ ' + (item.precio_costo || 0).toFixed(2)"></span>
                                        </td>
                                        <td class="px-4 py-3">
                                            <span :class="(item.stock_fisico - item.stock_actual) < 0 ? 'text-red-600 dark:text-red-400' : (item.stock_fisico - item.stock_actual) > 0 ? 'text-green-600 dark:text-green-400' : 'text-gray-600 dark:text-gray-400'"
                                                class="font-semibold text-sm"
                                                x-text="(item.stock_fisico - item.stock_actual) !== 0 ? 'S/ ' + (Math.abs(item.precio_costo * (item.stock_fisico - item.stock_actual)) || 0).toFixed(2) : 'S/ 0.00'"></span>
                                        </td>
                                        <td class="px-4 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                            <div class="flex items-center space-x-2">
                                                <button type="button"
                                                    @click.stop="exportarExcel()"
                                                    title="Exportar a Excel"
                                                    class="flex items-center justify-center text-white bg-green-600 hover:bg-green-700 focus:ring-4 focus:outline-none focus:ring-green-300 font-medium rounded text-sm p-2 text-center dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-900">
                                                    <i class="fas fa-file-excel h-4 w-4"></i>
                                                </button>
                                                <button type="button"
                                                    @click.stop="actualizarInventario()"
                                                    title="Actualizar Inventario"
                                                    class="flex items-center justify-center text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded text-sm p-2 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-900">
                                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                                                        <path fill-rule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clip-rule="evenodd"/>
                                                    </svg>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                </template>
                                <template x-if="inventarioFiltrado.length === 0">
                                    <tr>
                                        <td colspan="8" class="px-4 py-10 text-center text-gray-500 dark:text-gray-400">
                                            <i class="fas fa-box-open text-3xl mb-2 opacity-50"></i>
                                            <p>No se encontraron productos en inventario</p>
                                        </td>
                                    </tr>
                                </template>
                            </tbody>
                        </table>

                        
                        <div class="md:hidden px-3 space-y-3 pb-4">
                            <template x-for="(item, index) in inventarioFiltrado" :key="item.id">
                                <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
                                    
                                    <div class="px-4 pt-4 pb-3 flex items-center justify-between border-b border-gray-100 dark:border-gray-700">
                                        <div class="flex items-center gap-3 flex-1">
                                            <div class="w-10 h-10 rounded-full flex items-center justify-center bg-blue-100 dark:bg-blue-900/30">
                                                <i class="fas fa-boxes text-base text-blue-600 dark:text-blue-400"></i>
                                            </div>
                                            <div class="flex-1">
                                                <p class="text-sm font-semibold text-gray-900 dark:text-white" x-text="item.nombre"></p>
                                                <p class="text-xs text-gray-500 dark:text-gray-400" x-text="item.codigo"></p>
                                            </div>
                                        </div>
                                        <div class="text-right ml-3">
                                            <p class="text-sm font-bold text-gray-900 dark:text-white" x-text="item.stock_actual"></p>
                                            <p class="text-xs text-gray-500 dark:text-gray-400">Stock</p>
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="px-4 py-3">
                                        
                                        <div class="grid grid-cols-2 gap-3">
                                            <div class="flex flex-col">
                                                <p class="text-xs text-gray-500 dark:text-gray-400 mb-1">Lote</p>
                                                <p class="text-sm font-medium text-gray-900 dark:text-white leading-[38px]" x-text="item.lote || 'N/A'"></p>
                                            </div>
                                            <div class="flex flex-col">
                                                <p class="text-xs text-gray-500 dark:text-gray-400 mb-1">Físico</p>
                                                <input type="number" 
                                                    x-model="item.stock_fisico"
                                                    class="w-full h-[38px] px-2 text-sm text-gray-900 dark:text-white bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400"
                                                    min="0"
                                                    step="1">
                                            </div>
                                            <div>
                                                <p class="text-xs text-gray-500 dark:text-gray-400 mb-1">Diferencia</p>
                                                <p :class="(item.stock_fisico - item.stock_actual) > 0 ? 'text-green-600 dark:text-green-400' : (item.stock_fisico - item.stock_actual) < 0 ? 'text-red-600 dark:text-red-400' : 'text-gray-600 dark:text-gray-400'"
                                                    class="text-sm font-semibold"
                                                    x-text="(item.stock_fisico - item.stock_actual) > 0 ? '+' + (item.stock_fisico - item.stock_actual) : (item.stock_fisico - item.stock_actual)"></p>
                                            </div>
                                            <div>
                                                <p class="text-xs text-gray-500 dark:text-gray-400 mb-1">P. Costo</p>
                                                <p class="text-sm font-medium text-gray-900 dark:text-white" x-text="'S/ ' + ((item.precio_costo || 0).toFixed(2))"></p>
                                            </div>
                                            <div class="col-span-2 pt-2 border-t border-gray-100 dark:border-gray-700">
                                                <p class="text-xs text-gray-500 dark:text-gray-400 mb-1">Valor Diferencia</p>
                                                <p :class="(item.stock_fisico - item.stock_actual) < 0 ? 'text-red-600 dark:text-red-400' : (item.stock_fisico - item.stock_actual) > 0 ? 'text-green-600 dark:text-green-400' : 'text-gray-600 dark:text-gray-400'"
                                                    class="text-base font-bold"
                                                    x-text="(item.stock_fisico - item.stock_actual) !== 0 ? 'S/ ' + (Math.abs(item.precio_costo * (item.stock_fisico - item.stock_actual)) || 0).toFixed(2) : 'S/ 0.00'"></p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="px-4 pb-4 pt-3 border-t border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50">
                                        <div class="flex gap-2">
                                            <button type="button"
                                                @click.stop="exportarExcel()"
                                                title="Exportar a Excel"
                                                class="flex-1 flex items-center justify-center text-green-700 hover:text-white border border-green-700 hover:bg-green-800 focus:ring-4 focus:outline-none focus:ring-green-300 font-medium rounded-lg text-sm px-2 py-2 text-center dark:border-green-500 dark:text-green-500 dark:hover:text-white dark:hover:bg-green-600 dark:focus:ring-green-900">
                                                <i class="fas fa-file-excel mr-1 h-4 w-4"></i>
                                                Exportar
                                            </button>
                                            <button type="button"
                                                @click.stop="actualizarInventario()"
                                                title="Actualizar Inventario"
                                                class="flex-1 flex items-center justify-center text-blue-700 hover:text-white border border-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-2 py-2 text-center dark:border-blue-500 dark:text-blue-500 dark:hover:text-white dark:hover:bg-blue-600 dark:focus:ring-blue-900">
                                                <i class="fas fa-sync-alt mr-1"></i>
                                                Actualizar
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </template>
                            <template x-if="inventarioFiltrado.length === 0">
                                <div class="py-16 text-center">
                                    <div class="w-16 h-16 mx-auto mb-4 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
                                        <i class="fas fa-box-open text-2xl text-gray-400 dark:text-gray-500"></i>
                                    </div>
                                    <p class="text-gray-500 dark:text-gray-400 font-medium">No se encontraron productos en inventario</p>
                                </div>
                            </template>
                        </div>
                    </div>
                    <nav class="sticky bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700 shadow-lg md:shadow-none md:relative md:bg-transparent dark:md:bg-transparent"
                        aria-label="Table navigation">
                        <div class="flex flex-col md:flex-row justify-center md:justify-between items-center md:space-y-0 px-4 py-3 md:p-4">
                            <span class="text-xs md:text-sm text-gray-600 dark:text-gray-400 mb-2 md:mb-0 text-center md:text-left">
                                Mostrando
                                <span class="font-semibold text-gray-900 dark:text-white" x-text="inventarioFiltrado.length > 0 ? 1 : 0"></span>
                                -
                                <span class="font-semibold text-gray-900 dark:text-white" x-text="inventarioFiltrado.length"></span>
                                de
                                <span class="font-semibold text-gray-900 dark:text-white" x-text="inventarioFiltrado.length"></span>
                            </span>

                            <div class="flex items-center justify-center space-x-3 w-full md:w-auto">
                                <button type="button"
                                    class="flex-1 md:flex-none px-4 py-2.5 md:px-3 md:py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl md:rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 active:bg-gray-200 dark:active:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                                    disabled>
                                    <i class="fas fa-chevron-left"></i>
                                </button>
                                <span class="hidden md:inline-flex items-center justify-center text-sm py-2 px-3 leading-tight text-blue-600 bg-blue-50 border border-blue-300 dark:bg-blue-900 dark:border-blue-700 dark:text-blue-300">
                                    1
                                </span>
                                <button type="button"
                                    class="flex-1 md:flex-none px-4 py-2.5 md:px-3 md:py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl md:rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 active:bg-gray-200 dark:active:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                                    disabled>
                                    <i class="fas fa-chevron-right"></i>
                                </button>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </section>
    </div>
    
    
    <?php echo $__env->make('inventory.modals.update-inventory', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    
    <?php echo $__env->make('inventory.modals.export-loading', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</main>

<?php /**PATH C:\laragon\www\pos\resources\views/partials/table/table-inventory.blade.php ENDPATH**/ ?>